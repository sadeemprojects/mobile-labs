package com.example.studyplanner

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

// CSC 402 · Lecture 6 application — Study Planner
// Lecture slides: "Step 2 · The Route connects the ViewModel"
//                 "Step 3 · The Screen draws the state"
// Naming (Lecture 4): StudyPlannerRoute OWNS the state, StudyPlannerScreen only DRAWS.

// ───────────────────────── The Route: owns the state ─────────────────────────
@Composable
fun StudyPlannerRoute(viewModel: StudyPlannerViewModel = viewModel()) {

    // TODO 2 — Replace the placeholder line below with a draft text state that
    //          survives rotation: a var named draft, made with rememberSaveable,
    //          that starts as "".
    var draft by rememberSaveable { mutableStateOf("") }   // تم حل TODO 2

    StudyPlannerScreen(
        uiState = viewModel.uiState,            // state flows DOWN
        draft = draft,
        onDraftChange = {
            // TODO 3 — store the new text in draft (the new text is called it)
            draft = it   // تم حل TODO 3
        },
        onAddTask = {
            // TODO 4 — ask the ViewModel to add the draft, then clear draft ("")
            viewModel.addTask(draft)   // تم حل TODO 4 (إضافة المهمة)
            draft = ""                 // تفريغ الحقل
        }
    )
}

// ───────────────────────── The Screen: stateless ─────────────────────────────
@Composable
fun StudyPlannerScreen(
    uiState: StudyPlannerUiState,
    draft: String,
    onDraftChange: (String) -> Unit,
    onAddTask: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(16.dp)) {
        TaskCount(count = uiState.tasks.size)

        // TODO 5 — Show AddTaskRow here. Hand it:
        //          text = draft, onTextChange = onDraftChange, onAdd = onAddTask
        AddTaskRow(
            text = draft,
            onTextChange = onDraftChange,
            onAdd = onAddTask
        )   // تم حل TODO 5

        // TODO 6 — Show every task in uiState.tasks as a Text("• $task")
        //          (hint: uiState.tasks.forEach { task -> … })
        uiState.tasks.forEach { task ->
            Text("• $task")
        }   // تم حل TODO 6
    }
}

// ───────────────────────── Preview: no app, no ViewModel needed ──────────────
@Preview(showBackground = true)
@Composable
fun StudyPlannerScreenPreview() {
    StudyPlannerScreen(
        uiState = StudyPlannerUiState(tasks = listOf("Read Ch. 2", "Finish Lab 6")),
        draft = "",
        onDraftChange = {},
        onAddTask = {}
    )
}