package com.example.studyplanner.ui


import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

data class PlannerUiState(
    val studentName: String = "Student",
    val totalTasks: Int = 5,
    val completedTasks: Int = 0
)

@Composable
fun PlannerHomeScreen(
    uiState: PlannerUiState,
    onTaskCompleted: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "Welcome, ${uiState.studentName}!")
        Text(text = "Completed Tasks: ${uiState.completedTasks} / ${uiState.totalTasks}")

        Button(
            onClick = onTaskCompleted,
            enabled = uiState.completedTasks < uiState.totalTasks
        ) {
            Text(text = if (uiState.completedTasks >= uiState.totalTasks) "All Tasks Done!" else "Complete a Task")
        }
    }
}

@Composable
fun PlannerHomeRoute() {
    var uiState by remember {
        mutableStateOf(PlannerUiState(studentName = "Sadeem", totalTasks = 5, completedTasks = 0))
    }

    PlannerHomeScreen(
        uiState = uiState,
        onTaskCompleted = {
            if (uiState.completedTasks < uiState.totalTasks) {
                uiState = uiState.copy(completedTasks = uiState.completedTasks + 1)
            }
        }
    )
}

@Preview(showBackground = true, name = "Initial State")
@Composable
private fun PlannerHomePreviewInitial() {
    MaterialTheme {
        PlannerHomeScreen(
            uiState = PlannerUiState("Sadeem", 5, 0),
            onTaskCompleted = {}
        )
    }
}

@Preview(showBackground = true, name = "Completed State")
@Composable
private fun PlannerHomePreviewCompleted() {
    MaterialTheme {
        PlannerHomeScreen(
            uiState = PlannerUiState("Sadeem", 5, 5),
            onTaskCompleted = {}
        )
    }
}